# Fitness center static site template
